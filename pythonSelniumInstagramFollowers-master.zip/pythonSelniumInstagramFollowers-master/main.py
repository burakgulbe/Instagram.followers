import browser 

browser.Browser("https://www.instagram.com")
browser.time.sleep(1000)